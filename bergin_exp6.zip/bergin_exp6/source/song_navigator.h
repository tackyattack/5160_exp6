#ifndef SONG_NAVIGATOR_H
#define SONG_NAVIGATOR_H

#include "main.h"

//------- Public Constant definitions --------------------------------


// ------ Public function prototypes -------------------------------
void song_navigator_init(uint32_t root_dir);
void song_navigator_runner(void);

#endif
