#ifndef _LED_Control_H
#define _LED_Control_H

#include "main.h"
#include "PORT.H"



void LEDS_ON (uint8_t LED_mask);
void LEDS_OFF (uint8_t LED_mask);
void LED_number(uint8_t num);

#endif
